var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_genai = require("@google/genai");
var import_dotenv = __toESM(require("dotenv"), 1);
var import_firebase_admin = __toESM(require("firebase-admin"), 1);
var import_stripe = __toESM(require("stripe"), 1);
var import_twilio = __toESM(require("twilio"), 1);
var import_helmet = __toESM(require("helmet"), 1);
var import_cors = __toESM(require("cors"), 1);
var import_express_rate_limit = __toESM(require("express-rate-limit"), 1);
var import_morgan = __toESM(require("morgan"), 1);
var import_fs = __toESM(require("fs"), 1);
import_dotenv.default.config();
if (!import_firebase_admin.default.apps.length) {
  let projectId = process.env.GOOGLE_CLOUD_PROJECT;
  if (!projectId && import_fs.default.existsSync("firebase-applet-config.json")) {
    try {
      const config = JSON.parse(import_fs.default.readFileSync("firebase-applet-config.json", "utf8"));
      if (config.projectId) {
        projectId = config.projectId;
      }
    } catch (err) {
      console.warn("Failed to parse firebase-applet-config.json", err);
    }
  }
  if (projectId) {
    import_firebase_admin.default.initializeApp({ projectId });
  } else {
    import_firebase_admin.default.initializeApp();
  }
}
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  app.set("trust proxy", 1);
  app.use((0, import_helmet.default)({
    contentSecurityPolicy: process.env.NODE_ENV === "production" ? {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'", "https://js.stripe.com", "https://apis.google.com", "https://*.firebaseapp.com"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
        fontSrc: ["'self'", "https://fonts.gstatic.com"],
        imgSrc: ["'self'", "data:", "blob:", "https://images.unsplash.com", "https://firebasestorage.googleapis.com", "https://*.googleusercontent.com"],
        connectSrc: ["'self'", "https://api.stripe.com", "https://firestore.googleapis.com", "wss://*.firebaseio.com", "https://identitytoolkit.googleapis.com", "https://securetoken.googleapis.com", "https://www.googleapis.com", "https://*.firebaseapp.com"],
        frameSrc: ["'self'", "https://js.stripe.com", "https://*.firebaseapp.com"]
      }
    } : false,
    crossOriginEmbedderPolicy: false
  }));
  app.use((0, import_cors.default)());
  if (process.env.NODE_ENV === "production") {
    app.use((0, import_morgan.default)("combined"));
  } else {
    app.use("/api", (0, import_morgan.default)("dev"));
  }
  const apiLimiter = (0, import_express_rate_limit.default)({
    windowMs: 15 * 60 * 1e3,
    // 15 minutes
    max: 100,
    // limit each IP to 100 requests per windowMs
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: "Too many requests, please try again later." }
  });
  app.use("/api/", apiLimiter);
  app.use(import_express.default.json({ limit: "1mb" }));
  const requireAuth = async (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ error: "Unauthorized: missing Bearer token" });
    }
    const idToken = authHeader.split("Bearer ")[1];
    try {
      const decodedToken = await import_firebase_admin.default.auth().verifyIdToken(idToken);
      req.user = decodedToken;
      next();
    } catch (error) {
      console.error("Error verifying Firebase ID token:", error);
      return res.status(403).json({ error: "Unauthorized: invalid token" });
    }
  };
  const geminiKey = process.env.GEMINI_API_KEY;
  let ai = null;
  if (geminiKey) {
    ai = new import_genai.GoogleGenAI({
      apiKey: geminiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    });
  }
  const stripeSecretKey = process.env.STRIPE_SECRET_KEY;
  let stripe = null;
  if (stripeSecretKey) {
    stripe = new import_stripe.default(stripeSecretKey);
  }
  const twilioClient = process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN ? (0, import_twilio.default)(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN) : null;
  app.post("/api/messages/send", async (req, res) => {
    try {
      const { to, body, isWhatsApp } = req.body;
      if (!to || !body) {
        return res.status(400).json({ error: "Missing 'to' or 'body'" });
      }
      if (!twilioClient) {
        console.log(`[SIMULATED ${isWhatsApp ? "WHATSAPP" : "SMS"} to ${to}]: ${body}`);
        return res.json({ success: true, simulated: true });
      }
      const fromNumber = isWhatsApp ? process.env.TWILIO_WHATSAPP_NUMBER : process.env.TWILIO_PHONE_NUMBER;
      const toNumber = isWhatsApp ? to.startsWith("whatsapp:") ? to : `whatsapp:${to}` : to;
      if (!fromNumber) {
        return res.status(500).json({ error: "Twilio sender number not configured in env" });
      }
      const message = await twilioClient.messages.create({
        body,
        from: fromNumber,
        to: toNumber
      });
      res.json({ success: true, messageId: message.sid });
    } catch (error) {
      console.error("Twilio send error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app.post("/api/create-payment-intent", async (req, res) => {
    if (!stripe) {
      return res.status(500).json({ error: "Stripe is not configured on the server." });
    }
    try {
      const { amount, currency = "eur", paymentMethodTypes = ["card", "ideal"] } = req.body;
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100),
        // Stripe expects cents
        currency,
        payment_method_types: paymentMethodTypes
      });
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  app.post("/api/slots/hold", async (req, res) => {
    try {
      const { jamId, slotId, handle, whatsapp, email, name, offerRate, customAvailability } = req.body;
      if (!jamId || !slotId || !whatsapp || !email || !name) {
        return res.status(400).json({ error: "Missing required PII or slot data" });
      }
      const slotRef = import_firebase_admin.default.firestore().collection(`events/${jamId}/slots`).doc(slotId);
      const secureClaimRef = import_firebase_admin.default.firestore().collection(`events/${jamId}/slots/${slotId}/claims`).doc("current");
      await import_firebase_admin.default.firestore().runTransaction(async (tx) => {
        const slotSnap = await tx.get(slotRef);
        if (!slotSnap.exists) throw new Error("Slot not found");
        const slotData = slotSnap.data();
        if (slotData.status !== "open" && slotData.status !== "declined" && slotData.status !== "expired") {
          throw new Error("Slot not available for hold");
        }
        tx.set(secureClaimRef, {
          whatsapp,
          email,
          name,
          availability: customAvailability,
          offerRate,
          heldAt: (/* @__PURE__ */ new Date()).toISOString()
        });
        const expiresAt = /* @__PURE__ */ new Date();
        expiresAt.setMinutes(expiresAt.getMinutes() + 60);
        tx.update(slotRef, {
          status: "held",
          heldByMasked: `${name.substring(0, 2)}***`,
          holdExpiresAt: expiresAt.toISOString()
        });
      });
      res.json({ success: true });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: error.message });
    }
  });
  app.post("/api/slots/action", async (req, res) => {
    try {
      const { jamId, slotId, action, whatsapp, email } = req.body;
      const slotRef = import_firebase_admin.default.firestore().collection(`events/${jamId}/slots`).doc(slotId);
      const secureClaimRef = import_firebase_admin.default.firestore().collection(`events/${jamId}/slots/${slotId}/claims`).doc("current");
      await import_firebase_admin.default.firestore().runTransaction(async (tx) => {
        const slotSnap = await tx.get(slotRef);
        const claimSnap = await tx.get(secureClaimRef);
        if (!slotSnap.exists || !claimSnap.exists) throw new Error("Slot or claim not found");
        const claimData = claimSnap.data();
        const slotData = slotSnap.data();
        if (slotData.status !== "held") throw new Error("Slot not held");
        if (claimData.whatsapp !== whatsapp || claimData.email !== email) {
          throw new Error("Unauthorized: Identity mismatch");
        }
        if (action === "confirm") {
          tx.update(slotRef, { status: "confirmed", confirmedAt: (/* @__PURE__ */ new Date()).toISOString() });
        } else if (action === "decline") {
          tx.update(slotRef, {
            status: "open",
            lastDeclinedAt: (/* @__PURE__ */ new Date()).toISOString(),
            heldByMasked: import_firebase_admin.default.firestore.FieldValue.delete(),
            holdExpiresAt: import_firebase_admin.default.firestore.FieldValue.delete()
          });
        }
      });
      res.json({ success: true });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: error.message });
    }
  });
  app.post("/api/copilot/chat", requireAuth, async (req, res) => {
    try {
      const { message, tour, musicians, history } = req.body;
      if (!message || !tour || !musicians) {
        return res.status(400).json({ error: "Missing required properties in request payload." });
      }
      if (!ai) {
        const lower = message.toLowerCase();
        let fallbackMsg = "Hello! Sesseicat Copilot is online. ";
        let actions = [];
        if (lower.includes("roster") || lower.includes("budget") || lower.includes("build")) {
          fallbackMsg += "Based on your Show Budget constraint of \u20AC" + tour.budgetShow + ", I've selected the optimal empty slots for your tour.";
          const openRoles = tour.roleRequirements.filter((r) => r.status === "Open");
          const proposedHolds = openRoles.map((role) => {
            const fit = musicians.find(
              (m) => m.instruments.some((inst) => inst.toLowerCase().includes(role.roleName.split(" ")[0].toLowerCase()))
            ) || musicians[0];
            return {
              artistId: fit.id,
              role: role.roleName,
              rate: role.targetBudgetShow
            };
          });
          actions = [
            {
              intent: "build_roster",
              description: "Shortlist Optimal Candidates",
              params: {
                artistIds: proposedHolds.map((h) => h.artistId)
              }
            },
            {
              intent: "place_holds",
              description: "Lock 24H Exclusive Holds",
              params: {
                holds: proposedHolds
              }
            }
          ];
        } else if (lower.includes("hold") || lower.includes("lock")) {
          fallbackMsg += "I am ready to lock exclusive holds on the following artists so they are fully reserved for this stage schedule.";
          const proposed = tour.roleRequirements.map((role) => {
            const fit = musicians.find(
              (m) => m.instruments.some((inst) => inst.toLowerCase().includes(role.roleName.split(" ")[0].toLowerCase()))
            ) || musicians[0];
            return {
              artistId: fit.id,
              role: role.roleName,
              rate: role.targetBudgetShow
            };
          });
          actions = [
            {
              intent: "place_holds",
              description: "Place Holds on Candidate list",
              params: { holds: proposed }
            }
          ];
        } else if (lower.includes("draft") || lower.includes("message") || lower.includes("invite")) {
          fallbackMsg += "Drafting clean platform holds and NDA invitations for the shortlist. Ready for review.";
          const targetMusicians = musicians.slice(0, 2);
          actions = [
            {
              intent: "draft_messages",
              description: "Review hold message drafts",
              params: {
                drafts: targetMusicians.map((m) => ({
                  artistId: m.id,
                  text: `Hey ${m.name}! I would love to lock you in down as a standby on our upcoming tour. Here are the project details...`
                }))
              }
            }
          ];
        } else {
          fallbackMsg += "I'm your designated Tour Workspace Companion. Tell me to 'Build roster under budget', 'Place 24h holds on these', or 'Draft hold messages' to manage this touring campaign instantly.";
        }
        return res.json({
          response: fallbackMsg,
          actions
        });
      }
      const chatHistoryPrompt = history && history.length > 0 ? history.map((h) => `${h.sender === "user" ? "User" : "Assistant"}: ${h.text}`).join("\n") : "";
      const geminiResponse = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        config: {
          systemInstruction: 'You are Sessiecat Copilot, an operations assistant for touring managers, jam organisers, and session musicians in Europe.\n\nYour job\nHelp users plan tours/events and execute tasks inside Sessiecat:\nBuild rosters (band templates + candidates)\nShortlist musicians within budget\nPlace holds with expiry\nDraft messages and confirmations\nSummarize tour status (what\u2019s missing, who\u2019s confirmed)\nSuggest rehearsal/studio options (when asked)\n\nHard rules (no hallucinations)\nNever invent musicians, credits, availability, prices, studios, contracts, or policies.\nOnly use entities provided in the app context (IDs + fields).\nIf required data is missing, ask 1\u20132 clarifying questions and stop.\n\nPricing rules (transparent)\nMusicians set their own rates.\nAlways show \u20AC per show and calculate totals.\nWhen a hold is placed, the rate is locked for the hold duration and for the show if confirmed.\n\nDecision logic (how you choose)\nPrefer musicians who: match role + city/date availability + fit budget + high reliability (fast response, low no-show).\nIf budget is too low, propose the closest-fit roster and clearly mark which roles exceed budget.\n\nTone\nProfessional, fast, touring-ops vibe. No fluff. No long essays.\n\nOutput format (must be machine-readable)\nAlways return:\n1) A short human summary (max 6 lines)\n2) Then a JSON block matching this schema inside a ```json markdown block.\n\nJSON schema\n{\n  "intent": "build_roster | shortlist_candidates | place_holds | draft_messages | summarize_status | ask_clarifying_question",\n  "context": {\n    "tourId": "string|null",\n    "eventId": "string|null"\n  },\n  "constraints": {\n    "city": "string|null",\n    "date": "YYYY|null",\n    "rolesNeeded": ["string"],\n    "budgetTotalPerShow": "number|null",\n    "budgetPerRole": { "role": "number" }\n  },\n  "actions": [\n    {\n      "type": "SHORTLIST",\n      "role": "string",\n      "musicianIds": ["string"],\n      "reason": "string"\n    },\n    {\n      "type": "PLACE_HOLD",\n      "musicianId": "string",\n      "role": "string",\n      "rateLocked": "number",\n      "holdHours": 24\n    },\n    {\n      "type": "DRAFT_MESSAGE",\n      "toMusicianId": "string",\n      "messageType": "hold_request | confirmation | offer | follow_up",\n      "text": "string"\n    }\n  ],\n  "questions": ["string"]\n}'
        },
        contents: `Current Tour Workspace Context:
- ID: "${tour.id}"
- Name: "${tour.name}"
- Description: "${tour.description || "No description listed"}"
- Show budget target: \u20AC${tour.budgetShow}
- Role positions & states:
${tour.roleRequirements.map((r) => `  * ${r.roleName} (Status: ${r.status}, Target Budget: \u20AC${r.targetBudgetShow}, Standard Rate: \u20AC${r.actualRatePaidShow || "Not assigned"})`).join("\n")}

Elite Available Musicians Directory (No other musicians exist, do NOT invent any others):
${musicians.map((m) => `  * ID: "${m.id}", Name: "${m.name}", City: "${m.location || m.cityBase}", Instruments: ${m.instruments.join(", ")}, Day/Show Rate: \u20AC${m.dailyRate || m.hourlyRate * 3}, Rating: ${m.rating}, Availability: ${m.availability}, Tags: ${m.tags?.join(", ") || ""}`).join("\n")}

Previous dialogue:
${chatHistoryPrompt}

User's prompt: "${message}"`
      });
      const resultText = geminiResponse.text;
      if (!resultText) {
        throw new Error("Empty text returned from GenAI model");
      }
      const jsonStart = resultText.indexOf("```json");
      let responseText = resultText;
      let parsedActions = [];
      let parsedIntent = "None";
      if (jsonStart !== -1) {
        responseText = resultText.substring(0, jsonStart).trim();
        const jsonContent = resultText.substring(jsonStart + 7, resultText.lastIndexOf("```")).trim();
        try {
          const parsed = JSON.parse(jsonContent);
          parsedIntent = parsed.intent || "Unknown";
          if (parsed.actions) {
            parsedActions = parsed.actions.map((act) => {
              if (act.type === "SHORTLIST") {
                return {
                  intent: "shortlist_candidates",
                  description: act.reason || "Shortlisted candidate",
                  params: { artistIds: act.musicianIds }
                };
              }
              if (act.type === "PLACE_HOLD") {
                return {
                  intent: "place_holds",
                  description: `Place hold for ${act.role} at \u20AC${act.rateLocked}`,
                  params: { holds: [{ artistId: act.musicianId, role: act.role, rate: act.rateLocked }] }
                };
              }
              if (act.type === "DRAFT_MESSAGE") {
                return {
                  intent: "draft_messages",
                  description: `Draft ${act.messageType}`,
                  params: { drafts: [{ artistId: act.toMusicianId, text: act.text }] }
                };
              }
              return null;
            }).filter(Boolean);
          }
        } catch (e) {
          console.error("Failed to parse embedded JSON from AI model:", e, jsonContent);
        }
      }
      res.json({
        response: responseText,
        actions: parsedActions,
        intent: parsedIntent
      });
    } catch (err) {
      console.error("Error in Copilot Chat router:", err);
      res.status(500).json({ error: "Failed to generate copilot response. See server logs." });
    }
  });
  const scrapeCache = /* @__PURE__ */ new Map();
  const SCRAPE_CACHE_TTL = 60 * 60 * 1e3;
  app.post("/api/leads/search", requireAuth, async (req, res) => {
    try {
      const { query, type = "both" } = req.body;
      if (!query) {
        return res.status(400).json({ error: "Missing query" });
      }
      if (!ai) {
        return res.status(500).json({ error: "Gemini API key not configured on server" });
      }
      const cacheKey = `${query.trim().toLowerCase()}_${type}`;
      const cached = scrapeCache.get(cacheKey);
      if (cached && Date.now() - cached.timestamp < SCRAPE_CACHE_TTL) {
        return res.json(cached.data);
      }
      let promptStr = `You are a music industry scout. The user wants to find ${type === "gigs" ? "music gig opportunities" : type === "people" ? "booking agents / venue managers to contact" : "music gig opportunities AND people to contact"}.
Location/Genre context: "${query}"
Please search the web for real, current opportunities, venues, festivals, or contact persons in that area/genre. Summarize the findings with names, links, and contact info if available. Keep your response in Markdown, very structured and clean. Avoid making up fake emails. Use the Google Search tool.`;
      const geminiResponse = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        config: {
          tools: [{ googleSearch: {} }]
        },
        contents: promptStr
      });
      const resultText = geminiResponse.text;
      const chunks = geminiResponse.candidates?.[0]?.groundingMetadata?.groundingChunks;
      const links = chunks?.map((chunk) => chunk.web?.uri).filter(Boolean) || [];
      const responseData = {
        result: resultText,
        links: [...new Set(links)]
      };
      scrapeCache.set(cacheKey, {
        timestamp: Date.now(),
        data: responseData
      });
      res.json(responseData);
    } catch (err) {
      console.error("Error in AI Lead Scraper:", err);
      res.status(500).json({ error: "Failed to scrape leads. See server logs." });
    }
  });
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Express custom server running on port ${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
